﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SEProject
{
    public partial class Form6 : Form
    {
        string studentid;
        string classroomcode;
        public Form6(string studentid, string classroomcode)
        {
            this.studentid = studentid;
            this.classroomcode = classroomcode; 
           
            InitializeComponent();
            richTextBox1.Text = "Bring Laptops in your next class\nWe will have an online class coming Saturday";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7(studentid , classroomcode);
            this.Hide();
            form7.ShowDialog();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form8  form8 = new Form8(studentid , classroomcode);
            this.Hide();
            form8.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5(studentid);
            this.Hide();
            form5.ShowDialog();
        }
    }
}
