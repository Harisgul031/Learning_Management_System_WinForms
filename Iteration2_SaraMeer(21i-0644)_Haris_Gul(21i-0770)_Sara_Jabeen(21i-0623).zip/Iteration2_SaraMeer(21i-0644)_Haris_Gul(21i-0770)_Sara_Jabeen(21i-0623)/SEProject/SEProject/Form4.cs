﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace SEProject
{
    public partial class Form4 : Form
    {
        public string teacherId;
        public string classroomCode;
        //MessageBox.Show(classroomCode);

        private string connectionString = "Data Source=HARISGUL\\SQLEXPRESS;Initial Catalog=SEProject;Integrated Security=True";

        public Form4(string teacherId, string classroomCode)
        {
            InitializeComponent();
            this.teacherId = teacherId;
            this.classroomCode = classroomCode;
            richTextBox1.Text = "Quote of the Day\n\n'Be Kind, It makes you Beautiful'";
            // MessageBox.Show("Classroom Code: " + classroomCode + "\nTeacher ID: " + teacherId);
        }

        private void join_button_Click(object sender, EventArgs e)
        {
            string studentId = textBox1.Text;

            
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
               
                    connection.Open();

                   
                    string query = "INSERT INTO classroom_members (class_code, teacher_id, student_id) VALUES (@ClassCode, @TeacherId, @StudentId)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                       
                        command.Parameters.Add("@ClassCode", SqlDbType.VarChar, 50).Value = classroomCode;
                        command.Parameters.Add("@TeacherId", SqlDbType.VarChar, 50).Value = teacherId;
                        command.Parameters.Add("@StudentId", SqlDbType.VarChar, 50).Value = studentId;

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Student joined the classroom successfully!");
                        }
                        else
                        {
                            MessageBox.Show("Failed to join the classroom. Please try again.");
                        }
                    }
              
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3(teacherId);
            this.Hide();
            form3.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form9 form9 = new Form9(teacherId,classroomCode);
            this.Hide();
            form9.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Assignment_upload assignment_Upload = new Assignment_upload( teacherId, classroomCode);
            this.Hide();
            assignment_Upload.ShowDialog();

        }
    }
}
