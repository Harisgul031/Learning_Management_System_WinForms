﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace SEProject
{
    public partial class Form3 : Form
    {

        public string teacherId;
        public string classroomCode;

        public Form3(string teacherId)
        {
            InitializeComponent();
            this.teacherId = teacherId;
            ShowClassroomData();
        }
        private string connectionString = "Data Source=HARISGUL\\SQLEXPRESS;Initial Catalog=SEProject;Integrated Security=True";


        public Form3()
        {
            InitializeComponent();
        }

        private void ShowClassroomData()
        {
            try
            {
                // Create a SQL connection
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Open the connection
                    connection.Open();

                    // SQL query to select classroom data for the specific teacher ID
                    string query = "SELECT * FROM classroom WHERE teacher_id = @TeacherId";

                    // Create a SqlCommand object with the query and connection
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameter to the query to prevent SQL injection
                        command.Parameters.AddWithValue("@TeacherId", teacherId);

                        // Create a DataTable to store the results of the query
                        DataTable dataTable = new DataTable();

                        // Create a SqlDataAdapter to fill the DataTable with the query results
                        SqlDataAdapter dataAdapter = new SqlDataAdapter(command);

                        // Fill the DataTable
                        dataAdapter.Fill(dataTable);

                        // Bind the DataTable to the DataGridView
                        dataGridView1.DataSource = dataTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void createclassroom_Click(object sender, EventArgs e)
        {
           
                // Get the entered classroom code
                 classroomCode = classromcode.Text;

                // Assuming you have stored the teacher ID somewhere, replace 'user5' with the actual teacher ID
                //string teacherId = "user5"; // Example teacher ID

                // Create a SQL connection
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        // Open the connection
                        connection.Open();

                        // SQL query to insert the classroom data into the database
                        string query = "INSERT INTO classroom (classroom_code, teacher_id) VALUES (@ClassroomCode, @teacherId)";

                        // Create a SqlCommand object with the query and connection
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            // Add parameters to the query to prevent SQL injection
                            command.Parameters.AddWithValue("@ClassroomCode", classroomCode);
                            command.Parameters.AddWithValue("@TeacherId", teacherId);

                            // Execute the query
                            int rowsAffected = command.ExecuteNonQuery();

                            // Check if the insertion was successful
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Classroom created successfully!");
                            }
                            else
                            {
                                MessageBox.Show("Failed to create classroom. Please try again.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                
                }



            //MessageBox.Show("Classroom has been successfully created.");
        }

        private void classromcode_TextChanged(object sender, EventArgs e)
        {

        }

        private void classroom_Click(object sender, EventArgs e)
        {

            
            string classcode= openclass.Text;
            if (ValidateClassOwnership(classcode, teacherId))
            {
                MessageBox.Show("class joined successfully");
                Form4 form4 = new Form4(teacherId, classcode);
                this.Hide();
                form4.ShowDialog();
            }
            else
            {
                MessageBox.Show("Wrong classroom code, Kindly re-enter code");
            }
        }
        private bool ValidateClassOwnership(string classCode, string teacherId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT COUNT(*) FROM classroom WHERE classroom_code = @ClassCode AND teacher_id = @TeacherId";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ClassCode", classCode);
                        command.Parameters.AddWithValue("@TeacherId", teacherId);
                        int count = (int)command.ExecuteScalar();
                        return count > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error validating class ownership: " + ex.Message);
                return false;
            }
        }
        private void openclass_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ShowClassroomData();
        }
    }
}
