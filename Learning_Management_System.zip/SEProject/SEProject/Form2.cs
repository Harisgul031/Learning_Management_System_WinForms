﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace SEProject
{
    public partial class Form2 : Form
    {
        // Connection string to your SQL Server database
        private string connectionString = "Data Source=HARISGUL\\SQLEXPRESS;Initial Catalog=SEProject;Integrated Security=True";

        public Form2()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // This event is raised when the text in textBox1 changes
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            // This event is raised when the text in textBox2 changes
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            // This event is raised when the text in textBox3 changes
        }

        private void registered_Click(object sender, EventArgs e)
        {
            // Get the entered login ID, password, and confirm password
            string loginId = textBox1.Text;
            string password = textBox2.Text;
            string confirmPassword = textBox3.Text;
            string stafftype = textBox4.Text;
            string name = textBox5.Text;
            // Check if password and confirm password match
            if (password != confirmPassword)
            {
                MessageBox.Show("Password and confirm password do not match. Please try again.");
                return;
            }

            // Create a SQL connection
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    connection.Open();

                    // SQL query to insert the registration data into the database
                    string query = "INSERT INTO userr (username, name, password , staff_type ) VALUES (@Username, @name , @Password , @stafftype)";

                    // Create a SqlCommand object with the query and connection
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameters to the query to prevent SQL injection
                        command.Parameters.AddWithValue("@Username", loginId);
                        command.Parameters.AddWithValue("name", name);
                        command.Parameters.AddWithValue("@Password", password);
                        command.Parameters.AddWithValue("@stafftype", stafftype);

                        // Execute the query
                        int rowsAffected = command.ExecuteNonQuery();

                        // Check if the registration was successful
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Registration successful!");
                        }
                        else
                        {
                            MessageBox.Show("Registration failed. Please try again.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }

                Form1 form1 = new Form1();
                form1.Show();
                this.Hide();
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}