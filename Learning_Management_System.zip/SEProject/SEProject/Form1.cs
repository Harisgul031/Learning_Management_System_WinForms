﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace SEProject
{
    public partial class Form1 : Form
    {


      
        private string connectionString = "Data Source=HARISGUL\\SQLEXPRESS;Initial Catalog=SEProject;Integrated Security=True";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string loginId = textBox1.Text;
            string password = textBox2.Text;

        
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                   
                    connection.Open();

                    // SQL query to check if the login ID and password match any records in the database
                    string query = "SELECT COUNT(*) FROM userr WHERE username = @Username AND password = @Password";

                    // Create a SqlCommand object with the query and connection
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameters to the query to prevent SQL injection
                        command.Parameters.AddWithValue("@Username", loginId);
                        command.Parameters.AddWithValue("@Password", password);

                        // Execute the query and get the result
                        int count = (int)command.ExecuteScalar();

                        // Check if a record with the provided credentials exists
                        if (count > 0)
                        {
                            //MessageBox.Show("Login successful!");
                            Form5 form5 = new Form5(loginId);
                            this.Hide();
                            form5.ShowDialog();
                        }
                        else
                        {
                            MessageBox.Show("Invalid username or password. Please try again.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void RegisterB_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();

            // Show Form2
            form2.Show();
            this.Hide();
        }

        private void teacherlogin_Click(object sender, EventArgs e)
        {
            // Get the entered login ID and password
            string loginId = textBox1.Text;
            string password = textBox2.Text;

            // Create a SQL connection
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    connection.Open();

                    // SQL query to check if the login ID, password, and staff type match any records in the database
                    string query = "SELECT COUNT(*) FROM userr WHERE username = @Username AND password = @Password AND staff_type = 'teacher'";

                    // Create a SqlCommand object with the query and connection
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameters to the query to prevent SQL injection
                        command.Parameters.AddWithValue("@Username", loginId);
                        command.Parameters.AddWithValue("@Password", password);

                        // Execute the query and get the result
                        int count = (int)command.ExecuteScalar();
                        //object teacherIdObj = command.ExecuteScalar();
                        // Check if a record with the provided credentials exists for a teacher
                        if (count > 0)
                        {
                           // string teacherId = teacherIdObj.ToString();


                            Form3 form3 = new Form3(loginId);
                            form3.Show();
                            this.Hide();
                            //MessageBox.Show("Teacher login successful!");
                            // Redirect to teacher page or perform any other action for teacher login success
                        }
                        else
                        {
                            MessageBox.Show("Invalid username, password, or you are not a teacher. Please try again.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

    }
}
